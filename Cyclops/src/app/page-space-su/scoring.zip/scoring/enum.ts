export enum COLORS{
    GREY = "#A9A9A9",
    GREEN = "#006400",
    YELLOW = "#FFCA28",
    RED = "#DD2C00"

  }