import {StarSolutionTags} from "./StarSolutionTags"
export const StarSolutions : StarSolutionTags[] = [

    {
        stars : [1,2,3,4,5],
    
        starsols: [
            {
                star: 1,
                starsol : [ "Reduce meat consumption", "Forget about the labels"
        
                ]
        
            },
            {
                star: 2,
                starsol: [ "Try New things", "Find your high impact food"
        
                ]
            },
            {
                star: 3,
                starsol: [ "Live carlessly", "Reduce car use"
        
                ]
            },
            {
                star: 4,
                starsol: [ "Buy low emission vehicle", "Fill your car seats when you ride"
        
                ]
            },
            {
                star: 5,
                starsol: [ "star5solution", "Remember that everything a car powers depends on burning gasoline"
        
                ]
            }
        ],
    }

]