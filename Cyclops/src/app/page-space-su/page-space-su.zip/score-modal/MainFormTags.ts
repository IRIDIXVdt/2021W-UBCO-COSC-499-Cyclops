export type MainFormTags = {
	stars: number[];
	sections: string[];
};

export const MainFormTags: MainFormTags[] = [
	{
        stars: [1,2,3,4,5],
		sections: ["Transportation", "Food"]
	
	}
];