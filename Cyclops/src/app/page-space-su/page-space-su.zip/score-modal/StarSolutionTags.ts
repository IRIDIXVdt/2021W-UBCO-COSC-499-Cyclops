export class StarSolutionTags{
    stars : number[];
    starsols : {
        star : number;
        starsol : string[];
    }[];
}