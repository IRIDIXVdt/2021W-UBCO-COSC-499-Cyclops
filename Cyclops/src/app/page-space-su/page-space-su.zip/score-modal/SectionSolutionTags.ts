export class SectionSolutionTags{
    sections : string[];
    solution : {
        section : string;
        solutions : string[];
    }[];
}